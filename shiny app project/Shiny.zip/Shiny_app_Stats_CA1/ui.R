### Application name : CA1 B9DA101 - Statistics for Data Analytics 
### Course : MSc (Data Analytics) - Sep 2019 - Group D  
### Developed by : Ashwin Ramdas (10534162) / Utkarsh Gupta (10534526) / Karan Perla (10539155) / Akshay Sharma (10536542)  
### College : Dublin Business School  
#This application was made with the help of Rshiny to analyse the mtcars dataset, using descriptive analytics, 
#dicrete and continuous probability models and GLMs.


library(shiny)
# Define UI for application
shinyUI( fluidPage(

###>>> Begin >>> Ashwin Ramdas (10534162) >>> 
  # Header or Title Panel 
  titlePanel(title = h4("Analysis of mtcars dataset", align="center")),
  sidebarLayout(
    # Sidebar panel
    sidebarPanel(
      
          selectInput("conmodel", "Select Probabilistic Model: ",
                    
                    choices = c("Normal" = "normal",
                                
                                "Exponential" = "exponential"),
                    
                    selected = "normal"
                    
        ),

        conditionalPanel(    
          
          condition = "input.conmodel == 'exponential'",
          
          numericInput("lam", "parameter lambda in exponential distribution" , value = 1) 
          
        ),

###<<< End   <<< Ashwin Ramdas (10534162) <<< 

###>>> Begin >>> Utkarsh Gupta (10534526) >>>
		
        
        conditionalPanel(
          
          condition = "input.conmodel == 'normal'",
          numericInput("sigma", "parameter sigma in Normal distribution: " , min= 0, value = 1)
          
        ),
      selectInput("glm","Type of glm you want to do: ", c("Linear regression"="linear",
                                                          "Logistic regression"="logistic"), 
                                                          selected = NULL),
														  														  

      selectInput("hypothe","Type of hypothesis testing you want to do: ", c("two-tail"="twotail",
                                                                         "right tail"="right"),
                                                                          selected=NULL),

###<<< End   <<< Utkarsh Gupta (10534526) <<< 
		
###>>> Begin >>> Akshay Sharma (10536542) >>>		

																		  
      conditionalPanel(condition="input.hypothe",
                       sliderInput("HP",
                                   "value of hp variable for GLMs: ", 
                                   min = 52, max=335, value=146)
      ),
      conditionalPanel(condition="input.glm",
                       sliderInput("alpha", "value of alpha for hypothesis testing: ", min = 0.0, max=1.0, value=0.5),
                       sliderInput("n","sample size(n) for hypothesis testing: ",min = 4, max=30, value=20)
                      )
      ),
###<<< End   <<< Akshay Sharma (10536542) <<<	  
	  
###>>> Begin >>> Karan Perla (10539155) >>>

    # Main Panel
    mainPanel(
      tabsetPanel(
        
        tabPanel("Summary", verbatimTextOutput("summary"), tableOutput("view")),
        tabPanel("Models", plotOutput("histogram"),  tableOutput('tab'), tableOutput('prob')),
        tabPanel("hypothesis testing",
                 conditionalPanel(condition="input.hypothe=='twotail'",
                                  tabPanel("two tail test",
                                           verbatimTextOutput("twotail_model"))),
                 conditionalPanel(condition="input.hypothe=='right'",
                                  tabPanel("right tail test",
                                           textOutput("right_model"))),
                  ),
        
        tabPanel("GLM", tableOutput("glmodel"),conditionalPanel(condition="input.glm=='linear'", tabPanel("linear regression",verbatimTextOutput("linear_model"), plotOutput("linear_model1"))),
                                                 conditionalPanel(condition="input.glm=='logistic'", tabPanel("logistic regression", verbatimTextOutput("logistic_model"), plotOutput("logistic_model1"))))
                 )
                 )
###<<< End   <<< Karan Perla (10539155) <<< 
    )))
 