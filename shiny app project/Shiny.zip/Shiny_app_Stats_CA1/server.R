### Application name : CA1 B9DA101 - Statistics for Data Analytics 
### Course : MSc (Data Analytics) - Sep 2019 - Group D  
### Developed by : Ashwin Ramdas (10534162) / Utkarsh Gupta (10534526) / Karan Perla (10539155) / Akshay Sharma (10536542)  
### College : Dublin Business School  

library(shiny)
shinyServer(
  
  function(input, output) {
###>>> Begin >>> Ashwin Ramdas (10534162) >>>    
    output$linear_model<-renderPrint({   
        model_lm <- lm(mpg ~ hp, data= mtcars)
        NewInc <- data.frame(hp=input$HP)
        miles <- predict(model_lm,NewInc)
        print(miles)
    })
    output$linear_model1<-renderPlot({ 
        with(mtcars,plot(hp, mpg))
      model_lm1<-lm( mpg ~ hp, data= mtcars)
      abline(model_lm1)
        
        })
      output$logistic_model<-renderPrint({
        model_glm<-glm(vs ~ hp, data= mtcars, family="binomial")
        NewInc <- data.frame(hp=input$HP)
        miles <- predict(model_glm,NewInc)
        print(miles)
      })
###<<< End   <<< Ashwin Ramdas (10534162) <<< 	  
      
###>>> Begin >>> Utkarsh Gupta (10534526) >>>	  
	  
      output$logistic_model1<-renderPlot({
        with(mtcars,plot(hp, vs))
        model_glm1<-glm( vs ~ hp, data= mtcars, family="binomial")
        abline(model_glm1)
      })
      
     
      output$histogram <- renderPlot({
        
        
        
        # normal 
        
        if (input$conmodel == 'normal') {
          
          par(mfrow=c(1,2)) 
          
          x=mtcars$wt 
          
          plot(x,dnorm(x,mean(x),input$sigma),type='l', col='red') 
          
        }
        
###<<< End   <<< Utkarsh Gupta (10534526) <<<         
        
###>>> Begin >>> Karan Perla (10539155) >>>        
        
        # exponential
        
        if (input$conmodel == 'exponential') {
          
          par(mfrow=c(1,2))
          
          x=mtcars$qsec 
          
          plot(x,dexp(x,input$lam,log=FALSE),type='l',col='green')
          
        }
  
      })      
      
     output$twotail_model<- renderPrint({
       data<-mtcars$mpg
       t.test.twoTails <- function(data, n, alpha)
     { mu0=mean(data)
       xbar=mean(sample(data,size=input$n))
       t.stat <- abs((xbar - mu0)) / (sqrt(var(data) / length(data)))
       dof <- length(data) - 1
       t.critical <- qt(1-alpha/2, df= dof) #Es alpha 0.05 -> -1.9599 (df=Inf)
       p.value <- 2*(1-pt(t.stat, df= dof))

###<<< End   <<< Karan Perla (10539155) <<< 

###>>> Begin >>> Akshay Sharma (10536542) >>>
       
       if(t.stat >= t.critical)
       {
         pint<-print("Reject H0")
         pint
       }
       else
       {
         pint1<-print("Accept H0")
         pint1
       }
       print('T statistic')
       print(t.stat)
       print(c(-t.critical,t.critical))
       print('P value')
       print(p.value)
       print("#####################")
       
       return(t.stat)
     }

###<<< End   <<< Akshay Sharma (10536542) <<<

###>>> Begin >>> Ashwin Ramdas (10534162) >>>     
     t.test.twoTails(mtcars$drat, input$n, input$alpha)
     
          })
      
      output$tab <- renderTable({ 
        
        Normal=mtcars$drat 
        
        Exp=mtcars$qsec 
        
        
        
        if (input$conmodel == 'exponential') {
          
          d2=data.frame(Exp) 
          
        }
        
        else
          
        {
          
          d1=data.frame(Normal) 
          
        }
        
      }) 

         output$right_model<-renderPrint({
        data<mtcars$mpg
        t.test.right <- function(data, n, alpha)
        { n=input$n
          mu0=mean(data)
          xbar=mean(sample(data,size=input$n))

###<<< End   <<< Ashwin Ramdas (10534162) <<< 

###>>> Begin >>> Utkarsh Gupta (10534526) >>>
          
          t.stat <- (xbar - mu0) / (sqrt(var(data) / length(data)))
          dof <- length(data) - 1
          t.critical <- qt(1-alpha, df= dof) #Es alpha 0.05 -> 1.64 (df=Inf)
          p.value <- 1 - pt(t.stat, df= dof)
          
          if(t.stat >= t.critical)
          {
            print("Reject H0")
          }
          else
          {
            print("Accept H0")
          }

          print('T statistic')
          print(t.stat)
          print('T critical value')
          print(t.critical)
          print('P value')
          print(p.value)
          print("#####################")
          
          return(t.stat)
        }
        
        t.test.right(data,input$n, input$alpha)
        
     
      })

###<<< End   <<< Utkarsh Gupta (10534526) <<<  

###>>> Begin >>> Karan Perla (10539155) >>>

      output$prob <- renderPrint({ 
        
        p1=pnorm(mtcars$drat,mean(mtcars$drat), input$sigma) 
        
        p2=pexp(mtcars$qsec ,input$lam) 
        
        if (input$conmodel == 'exponential') {
          
          c(p2) 
          
        }
        if (input$conmodel == 'normal') {
          
          c(p1) 
        }
      }) 
      
      output$left_model<-renderPlot({
        data<-mtcars$hp
        
        t.test.left <- function(data, n, alpha)
        {n=input$n 
        mu0=mean(data)
        xbar=mean(sample(data,size=input$n))
        t.stat <- (xbar - mu0) / (sqrt(var(data) / length(data)))
        dof <- length(data) - 1
        t.critical <- qt(alpha, df= dof) #Es alpha 0.05 -> -1.64 (df=Inf)
        p.value <- pt(t.stat, df= dof)

###<<< End   <<< Karan Perla (10539155) <<< 

###>>> Begin >>> Akshay Sharma (10536542) >>>
        
        if(t.stat <= t.critical)
        {
          print("Reject H0")
        }
        else
        {
          print("Accept H0")
        }
        print('T statistic')
        print(t.stat)
        print('T critical value')
        print(t.critical)
        print('P value')
        print(p.value)
        print("#####################")
        } 
        
        t<-t.test.left(data, input$n, input$alpha)
      })
        
    output$view <- renderTable({
      head(mtcars)
    })
    
    output$summary <- renderPrint({
      summary(mtcars)  
###<<< End   <<< Akshay Sharma (10536542) <<<
    })
  })
