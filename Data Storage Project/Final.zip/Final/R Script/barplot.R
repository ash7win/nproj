d <- sqlQuery(conn,'SELECT c.gender,count(l.loan_id) "Number of Loans taken" FROM loan_fact l JOIN client_dim c on l.client_id=c.client_id group by c.gender order by 1 desc;' )
d

dat<-data.frame(d)

barplot(dat$Number.of.Loans.taken, main="Loan by Gender",
        xlab="Number of Years", ylab="Loan Taken", col = "tomato3")