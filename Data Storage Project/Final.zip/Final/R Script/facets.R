
c <- sqlQuery(conn,'SELECT district_name, loan_year, count(loan_id) "No. of loans taken" FROM loan_fact lf join calendar_dim cal on lf.calendar_id=cal.calendar_id group by district_name, loan_year order by 2 desc, 1;' )

df<-data.frame(c)

df1 <- df %>% top_n(5)

df1
library(ggplot2)
theme_set(theme_classic())




b <- ggplot(df, aes(x=df$No..of.loans.taken, y=df$district_name, fill=df$loan_year))         
b


h <- b + geom_point(aes(fill=df$loan_year), colour="Black")



d <- h + facet_grid(.~df$loan_year, scales="free")

e <- d + ylim("Benesov","Cheb","Klatovy","Zlin","Rokycany") + xlim(0,100)
f <- e + theme(
  panel.background = element_rect(fill = "lightblue",
                                  colour = "lightblue",
                                  size = 0.5, linetype = "solid"),
  panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                  colour = "white"), 
  panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                  colour = "white")
)


g <- f + xlab("No. Of Loans Taken") + ylab("District Name") + theme(axis.title.x=element_text(colour="Black", size=15 ),
                                                            axis.title.y=element_text(colour="Black", size=15),
                                                            axis.text.x=element_text(size=10),
                                                            axis.text.y=element_text(size=10),
                                                            legend.title=element_text(size=10),
                                                            legend.text=element_text(size=10))
                                                        

l <- g + ggtitle("LOANS PER YEAR IN DISTRICTS")