a <- sqlQuery(conn,'SELECT l.client_id, c.gender, c.birth_date, avg(duration) "Average Tenure"
FROM loan_fact  l JOIN client_dim c on l.client_id=c.client_id
group by l.client_id, c.gender, c.birth_date
order by 4 desc;' )

a
der<-data.frame(a)

b <- boxplot(Average.Tenure~gender,
        data=der,
        main="BOX PLOTS FOR DIFFERENT GENDER",
        xlab="Gender",
        ylab="Average Tenure",
        col="yellow",
        border="blue"
)
c <- b + theme(
  panel.background = element_rect(fill = "lightblue",
                                  colour = "lightblue",
                                  linetype = "solid"))
c
