a <- sqlQuery(conn,'SELECT year(cal.full_date) - year(cli.birth_date) "Age", count(lf.loan_id) "Number of loans taken"  , sum(lf.amount)   "Sum Amount"  
FROM loan_fact lf join client_dim cli on lf.client_id=cli.client_id join calendar_dim cal on lf.calendar_id=cal.calendar_id group by year(cal.full_date)-year(cli.birth_date)
order by 1 asc;' )
a
data<-data.frame(a)
o<-ggplot(data, aes(x = Age, y =Number.of.loans.taken)) +
  geom_point(aes(size=Sum.Amount),color="Black") 
f <- o  + ylim(0,500) + theme(
  panel.background = element_rect(fill = "lightblue",
                                  colour = "lightblue",
                                  size = 0.5, linetype = "solid"),
  panel.grid.major = element_line(size = 0.5, linetype = 'solid',
                                  colour = "white"), 
  panel.grid.minor = element_line(size = 0.25, linetype = 'solid',
                                  colour = "white")
)

f + ggtitle("LOAN AMOUNT TAKEN BY AGE GROUPS")
